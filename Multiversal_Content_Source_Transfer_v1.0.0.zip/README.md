# Multiversal Content Source Transfer

This package contains **487 verified canonical game-object records** extracted from the Multiversal project-source archives.

## Upload destination

Upload:

`content-source/phase-1-8-canonical-objects.json`

to:

`cybalicistjt-stack/multiversal-aioc`

The existing database generator scans `content-source/` automatically during GitHub Pages deployment.

## Validation

- Unique stable IDs: 487
- Duplicate stable-ID conflicts: 0
- SHA-256: `11d3e26161a6ea1acbe8847d7c01c5f6fb09a9525dc2e2eba557d41b4c612fbb`

The `reports/` directory contains the complete inventory and object-type summary.
